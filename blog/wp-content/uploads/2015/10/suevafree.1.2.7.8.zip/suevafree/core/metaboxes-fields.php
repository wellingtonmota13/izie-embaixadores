<?php

$suevafree_article = array (

array( "name" => __( "General Settings","wip"),
	   "type" => "title",
	   "id" => "title",
      ),
	  
array( "name" => __( "Template","wip"),
	   "desc" => __( "Select a template for this page","wip"),
	   "id" => "suevafree_template",
	   "type" => "select",
	   "options" => array(
		   "full" => __( "Full Width","wip"),
	   	   "left-sidebar" =>  __( "Left Sidebar","wip"),
	   	   "right-sidebar" => __( "Right Sidebar","wip"),
      ),
 	  ),
	  
);

?>